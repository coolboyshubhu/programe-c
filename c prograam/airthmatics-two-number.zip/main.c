/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b;
    printf("enter the first value");
    scanf("%d",&a);
    printf("enter the secound value");
    scanf("%d",&b);
    printf("the result =%d",a+b);
    printf("the result=%d",a-b);
    printf("the result=%d",a*b);
    printf("the result%d",a/b);

    return 0;
}
