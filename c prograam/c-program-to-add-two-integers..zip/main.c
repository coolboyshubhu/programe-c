/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num1,num2;
    printf("enter the first value of num1=");
    scanf("%d",&num1);
    printf("enter the secound value of num2=");
    scanf("%d",&num2);
    printf("the reasult =%d",num1+num2);

    return 0;
}
