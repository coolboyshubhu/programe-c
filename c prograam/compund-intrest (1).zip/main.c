/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
 float p,r,t,ci;
 printf("enter the value of principal");
 scanf("%f",&p);
 printf("enter the value of rate");
 scanf("%f",&r);
 printf("enter the value of time");
 scanf("%f",&t);
printf("compound intrest=%f",p*(1+r/100*t));
    return 0;
}
