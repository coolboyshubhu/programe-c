/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float cm,meter,kilometer;
    scanf("%f",&cm);
    printf("enter the length in centimeter");
    scanf("%f",&meter);
    printf("enter the length in meter");
    scanf("%f",&kilometer);
    printf("enter the length in kilometer");
printf("the reasult=%f",cm/100);
printf("the reasult=%f",meter/1000);
    return 0;
}
