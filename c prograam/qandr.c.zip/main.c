/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int
main ()
{
  int a, b;
  printf ("enter the first no. to divide");
    scanf("%d",&a);
    printf("enter the second no. to divide");
    scanf ("%d", &b);
    printf("the quotient of given input=%d",a/b);
    printf("\n the reminder of given input=%d",a%b);

  return 0;
}
