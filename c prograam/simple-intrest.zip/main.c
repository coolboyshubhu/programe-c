/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
float p,r,t,si;
printf("enter the value of the principle");
scanf("%f",&p);
printf("enter the value of the rate ");
scanf("%f",&r);
printf("enter the value of the time");
scanf("%f",&t);
printf("enter the value of the simple intrest");
scanf("%f",&si);
printf("simple intrest=%f",p*r*t/100);


    return 0;
}
