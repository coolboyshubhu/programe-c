/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int inttype;
float floattype;
char chartype;
double doubletype;
printf("size of int is%ld\n");
printf("size of float is%ld\n");
printf("size of char is%ld\n");
printf("size of double is%ld\n");

    return 0;
}
